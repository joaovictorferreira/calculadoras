package com.rpc

import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.java.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import java.util.*

// Client Stub: abstrai a chamada remota como metodos locais
class CalculatorRpcClient(private val client: HttpClient, private val endpoint: String) : CalculatorService {
    private suspend fun invokeRemote(method: String, a: Double = 0.0, b: Double = 0.0, expr: String = ""): Double {
        val response = client.post(endpoint) {
            contentType(ContentType.Application.Json)
            setBody(RpcRequest(method, a, b, expr))
        }.body<RpcResponse>()

        return response.result ?: throw RuntimeException(response.error ?: "Erro RPC desconhecido")
    }

    override suspend fun somar(a: Double, b: Double): Double = invokeRemote("somar", a, b)
    override suspend fun subtrair(a: Double, b: Double): Double = invokeRemote("subtrair", a, b)
    override suspend fun multiplicar(a: Double, b: Double): Double = invokeRemote("multiplicar", a, b)
    override suspend fun dividir(a: Double, b: Double): Double = invokeRemote("dividir", a, b)
    override suspend fun avaliarExpressao(expr: String): Double = invokeRemote("avaliarExpressao", expr = expr)
}

//Chama no servidor o metodo remoto correspondente ao operador
suspend fun chamar(calc: CalculatorService, op: Char, a: Double, b: Double): Double = when (op) {
    '-' -> calc.subtrair(a, b)
    '*' -> calc.multiplicar(a, b)
    '/' -> calc.dividir(a, b)
    else -> calc.somar(a, b)
}

//Abordagem 1: o cliente interpreta a expressao e faz uma chamada remota por operacao
suspend fun calcularDecompondo(calc: CalculatorService, expr: String): Double =
    Expressao.avaliar(expr) { op, a, b ->
        val r = chamar(calc, op, a, b)
        println("   chamada remota: $a $op $b -> $r")
        r
    }

fun main() = runBlocking {
    val httpClient = HttpClient(Java) {
        install(ContentNegotiation) {
            json()
        }
        engine {
            dispatcher = Dispatchers.IO
        }
    }

    val calculator: CalculatorService = CalculatorRpcClient(httpClient, "http://localhost:8080/rpc")
    val scanner = Scanner(System.`in`)

    println("=== Cliente Calculadora RPC Conectado (Engine Java) ===")

    while (true) {
        print("\nDigite a operacao (+, -, *, /, 'expr' ou 'sair'): ")
        val op = scanner.nextLine().trim()
        if (op.equals("sair", ignoreCase = true)) break

        try {
            if (op.equals("expr", ignoreCase = true)) {
                print("Expressao (ex: (10+15)*4 ): ")
                val expr = scanner.nextLine().trim()
                print("1-decompor no cliente  2-calcular no servidor: ")
                val modo = scanner.nextLine().trim()

                val resultado = if (modo == "1") calcularDecompondo(calculator, expr)
                else calculator.avaliarExpressao(expr)
                println("-> Resposta remota do servidor: $resultado")

            } else if (op in listOf("+", "-", "*", "/")) {
                print("Primeiro numero: ")
                val a = scanner.nextLine().trim().replace(",", ".").toDouble()

                print("Segundo numero: ")
                val b = scanner.nextLine().trim().replace(",", ".").toDouble()

                println("-> Resposta remota do servidor: ${chamar(calculator, op[0], a, b)}")

            } else {
                println("Operacao invalida! Use '+', '-', '*', '/' ou 'expr'.")
            }
        } catch (e: Exception) {
            println("-> Falha RPC: ${e.message}")
        }
    }

    httpClient.close()
    println("Cliente finalizado.")
}