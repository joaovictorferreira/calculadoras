package com.rpc

import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

class CalculatorServiceImpl : CalculatorService {
    override suspend fun somar(a: Double, b: Double): Double {
        println("[Servidor] Calculando soma: $a + $b")
        return a + b
    }

    override suspend fun subtrair(a: Double, b: Double): Double {
        println("[Servidor] Calculando subtracao: $a - $b")
        return a - b
    }

    override suspend fun multiplicar(a: Double, b: Double): Double {
        println("[Servidor] Calculando multiplicacao: $a * $b")
        return a * b
    }

    override suspend fun dividir(a: Double, b: Double): Double {
        println("[Servidor] Calculando divisao: $a / $b")
        if (b == 0.0) throw ArithmeticException("divisao por zero")
        return a / b
    }

    //Avalia a expressao inteira aqui no servidor
    override suspend fun avaliarExpressao(expr: String): Double {
        println("[Servidor] Avaliando expressao: $expr")
        return Expressao.avaliar(expr) { op, x, y ->
            when (op) {
                '-' -> subtrair(x, y)
                '*' -> multiplicar(x, y)
                '/' -> dividir(x, y)
                else -> somar(x, y)
            }
        }
    }
}

fun main() {
    val service: CalculatorService = CalculatorServiceImpl()

    embeddedServer(Netty, port = 8080) {
        install(ContentNegotiation) {
            json()
        }

        routing {
            post("/rpc") {
                val req = call.receive<RpcRequest>()
                try {
                    val resultado = when (req.method) {
                        "somar" -> service.somar(req.a, req.b)
                        "subtrair" -> service.subtrair(req.a, req.b)
                        "multiplicar" -> service.multiplicar(req.a, req.b)
                        "dividir" -> service.dividir(req.a, req.b)
                        "avaliarExpressao" -> service.avaliarExpressao(req.expr)
                        else -> null
                    }

                    if (resultado != null) {
                        call.respond(RpcResponse(result = resultado))
                    } else {
                        call.respond(RpcResponse(error = "Metodo '${req.method}' desconhecido"))
                    }
                } catch (e: RuntimeException) {
                    //erro de calculo ou expressao invalida vai no campo error do JSON-RPC
                    call.respond(RpcResponse(error = e.message))
                }
            }
        }
    }.start(wait = true)
}