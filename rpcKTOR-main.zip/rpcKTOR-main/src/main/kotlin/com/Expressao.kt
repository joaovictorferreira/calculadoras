package com.rpc

// Interpreta expressoes como (10+15)*4.
// Quem decide como cada operacao e executada e a funcao recebida:
// no servidor ela calcula local, no cliente ela faz uma chamada remota.
class Expressao private constructor(texto: String, private val op: suspend (Char, Double, Double) -> Double) {

    private val s = texto.replace(" ", "")
    private var i = 0

    companion object {
        suspend fun avaliar(texto: String, op: suspend (Char, Double, Double) -> Double): Double {
            val e = Expressao(texto, op)
            val v = e.soma()
            if (e.i < e.s.length) throw IllegalArgumentException("expressao invalida")
            return v
        }
    }

    //trata + e -
    private suspend fun soma(): Double {
        var v = produto()
        while (i < s.length && (s[i] == '+' || s[i] == '-')) {
            val operador = s[i++]
            v = op(operador, v, produto())
        }
        return v
    }

    //trata * e / . Fica num nivel mais interno que a soma, por isso resolve primeiro
    private suspend fun produto(): Double {
        var v = valor()
        while (i < s.length && (s[i] == '*' || s[i] == '/')) {
            val operador = s[i++]
            v = op(operador, v, valor())
        }
        return v
    }

    //trata um numero ou um grupo entre parenteses
    private suspend fun valor(): Double {
        if (s[i] == '(') {
            i++
            val v = soma()
            if (i >= s.length || s[i] != ')') throw IllegalArgumentException("falta fechar parentese")
            i++
            return v
        }
        val ini = i
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        return s.substring(ini, i).toDouble()
    }
}